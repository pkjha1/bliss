interface Window {
  initMap: () => void
  google?: any
}

