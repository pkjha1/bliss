export { PlacesMapFixed } from "../places-map-fixed"

